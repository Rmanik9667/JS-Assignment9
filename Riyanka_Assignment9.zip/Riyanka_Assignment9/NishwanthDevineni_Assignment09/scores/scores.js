"use strict";
$(document).ready(function() {
        var array = new Array();
        var stu = new Array();
    var displayScores = function () {   
       var totalScore = 0;
        var numberOfScores =0;
        var averageScore=0;
        
        var str='';
        for( var i=0; i<array.length && i<stu.length;i++)
            {
                str +=stu[i]+" "+array[i];
            }
        $("#scores").val(str);
        for( var i=0;i<array.length;i++)
            {
                totalScore=Number(totalScore)+Number(array[i]);
                numberOfScores++;
                averageScore=Number(totalScore)/Number(numberOfScores);
                $("#average_score").val(averageScore);
            }
    };
    
    $("#add_button").click(function() {
         var fname=$("#first_name").val();
		var lname=$("#last_name").val();
		fname+=" "+lname;
		var score=$("#score").val()+"\n";
		
		array.push(score);
		
		stu.push(fname);
		displayScores();
        
        // get the add form ready for next entry
        $("#first_name").val( "" );
        $("#last_name").val( "" );
        $("#score").val( "" );
        $("#first_name").focus();
    }); // end click()
    
    $("#clear_button").click(function() {
        $("#first_name").val( "" );
		
		$("#last_name").val( "" );
		
		$("#score").val( "" );
		
		$("#first_name").focus();
		array.length=0;
		stu.length=0;

        // remove the score data from the web page
        $("#average_score").val( "" );
        $("#scores").val( "" );

        $("#first_name").focus();
    }); // end click()
       
    $("#sort_button").click(function() {
stu.sort();
        $("#scores").val(stu);
    }); // end click()
    
    $("#first_name").focus();
}); // end ready()